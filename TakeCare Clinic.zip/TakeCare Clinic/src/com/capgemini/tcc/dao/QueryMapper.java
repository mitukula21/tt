package com.capgemini.tcc.dao;

public interface QueryMapper 
{
	
	
	public static final String VIEW_PATIENT_DETAILS_QUERY="SELECT patient_name,age,phone,description,consultation_date FROM patient WHERE  patient_id=?";
	public static final String INSERT_QUERY="INSERT INTO patient VALUES(patient_id_seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String PATIENTID_QUERY_SEQUENCE="SELECT patient_id_seq.CURRVAL FROM DUAL";
	
	
}

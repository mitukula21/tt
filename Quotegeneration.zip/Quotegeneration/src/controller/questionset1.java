package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
 
import javax.jws.WebService;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/questionset1")
public class questionset1 extends HttpServlet
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response)  
	{
		try
		{
		RequestDispatcher rd = null;
		PreparedStatement ps=null;		
		ResultSet rs = null;
		Class.forName("oracle.jdbc.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
		int a4=0;
		PrintWriter out=response.getWriter();
		String temp="";
		String a1=request.getParameter("question1");
		String a2=request.getParameter("question2");
		String a3=request.getParameter("question3");
		temp=request.getParameter("question4");
		a4=Integer.parseInt(temp);
		String seq ="Select uses.NEXTVAL from DUAL";
		String sql="SELECT uses.CURRVAL FROM DUAL";
		ps = c.prepareStatement(seq);
		rs=ps.executeQuery();
		ps = c.prepareStatement(sql);
		rs=ps.executeQuery();
		int qid=0;
		if(rs.next())
		{
			qid=rs.getInt(1);
 
		}
		System.out.println(qid);
		String q1="what is ur name";
		String q2="what is ur fav subject";
		String q3="what is ur birth places";
		String q4="what is age";
		String sqlins ="Insert into questionsandanswers values(?,?,?,?,?,?,?,?,?)";
		ps = c.prepareStatement(sqlins);
		ps.setInt(1,qid);
		ps.setString(2,q1);			
		ps.setString(3,a1);	
		ps.setString(4,q2);			
		ps.setString(5,a2);	
		ps.setString(6,q3);			
		ps.setString(7,a3);	
		ps.setString(8,q4);			
		ps.setInt(9,a4);	
		ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
 
	}
}
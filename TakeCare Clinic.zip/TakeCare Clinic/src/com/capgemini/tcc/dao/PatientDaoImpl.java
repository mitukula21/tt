package com.capgemini.tcc.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBConnection;


public class PatientDaoImpl implements IPatientDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public PatientDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addDonorDetails(DonorBean donor)
	 - Input Parameters	:	DonorBean donor
	 - Return Type		:	String
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2018
	 - Description		:	Adding Donor
	 ********************************************************************************************************/

	public String addPatientDetails(PatientBean patient) throws PatientException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String patientId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,patient.getPname());			
			preparedStatement.setString(4,patient.getPdesc());
			preparedStatement.setString(3,patient.getPno());
			preparedStatement.setDouble(2,patient.getAge());			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				patientId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new PatientException("Inserting patient details failed ");

			}
			else
			{
				logger.info("Patient details added successfully:");
				return patientId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientException("Tehnical problem occured please refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
		
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewDonorDetails(String donorId)
	 - Input Parameters	:	donorId
	 - Return Type		:	DonorBean
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2018
	 - Description		:	ViewDonorDetails
	 ********************************************************************************************************/
	public PatientBean viewPatientDetails(String pid) throws PatientException {
		
		Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		PatientBean bean=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper.VIEW_PATIENT_DETAILS_QUERY);
			preparedStatement.setString(1,pid);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				bean = new PatientBean();
				bean.setPname(resultset.getString(1));
				bean.setPdesc(resultset.getString(4));
				bean.setPno(resultset.getString(3));
				bean.setPdate(resultset.getDate(5));
				bean.setAge(resultset.getInt(2));
					
			}
			
			if( bean != null)
			{
				logger.info("Record Found Successfully");
				return bean;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new PatientException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new PatientException("Error in closing db connection");

			}
		}
		
	}

	


	

}

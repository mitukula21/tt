package com.nag;

public class BusinessBean
{
	private String vehicletype;
	private String vehiclemy;
	private String vehiclemodel;
	private String dailycd;
	private String servicecenter;
	private String limit;
	private String limit2;
	public String getVehicletype() {
		return vehicletype;
	}
	public String getVehiclemy() {
		return vehiclemy;
	}
	public String getVehiclemodel() {
		return vehiclemodel;
	}
	public String getDailycd() {
		return dailycd;
	}
	public String getServicecenter() {
		return servicecenter;
	}
	public String getLimit() {
		return limit;
	}
	public String getLimit2() {
		return limit2;
	}
	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}
	public void setVehiclemy(String vehiclemy) {
		this.vehiclemy = vehiclemy;
	}
	public void setVehiclemodel(String vehiclemodel) {
		this.vehiclemodel = vehiclemodel;
	}
	public void setDailycd(String dailycd) {
		this.dailycd = dailycd;
	}
	public void setServicecenter(String servicecenter) {
		this.servicecenter = servicecenter;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	public void setLimit2(String limit2) {
		this.limit2 = limit2;
	}
	
}

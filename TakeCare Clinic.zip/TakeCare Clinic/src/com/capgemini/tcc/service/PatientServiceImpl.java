package com.capgemini.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDaoImpl;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientServiceImpl implements IPatientService {
	
	IPatientDAO patientDao;
	
	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addDonorDetails
	 - Input Parameters	:	donor object
	 - Return Type		:	String id
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/11/2016
	 - Description		:	adding donor to database calls dao method addDonorDetails(donor)
	 ********************************************************************************************************/
	public String addPatientDetails(PatientBean patient) throws PatientException {
		patientDao=new PatientDaoImpl();	
		String patientSeq;
		patientSeq= patientDao.addPatientDetails(patient);
		return patientSeq; 
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewDonorDetails
	 - Input Parameters	:	String donorId
	 - Return Type		:	donor object
	 - Throws		    :  	DonorException
	 - Author		    :	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	calls dao method viewDonorDetails(donorId)
	 ********************************************************************************************************/
	public PatientBean viewPatientDetails(String pid) throws PatientException {
		patientDao=new PatientDaoImpl();
		PatientBean bean=null;
		bean=patientDao.viewPatientDetails(pid);
		return bean;
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : DonorException
	 - Author	      	: CAPGEMINI 
	 - Creation Date	: 18/11/2016
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	/*public List<PatientBean> retriveAll() throws PatientException {
		donorDao=new PatientDaoImpl();
		List<PatientBean> donorList=null;
		donorList=donorDao.retriveAllDetails();
		return donorList;
	}*/
	
	
	/*******************************************************************************************************
	 - Function Name	: validateDonor(DonorBean bean)
	 - Input Parameters	: DonorBean bean
	 - Return Type		: void
	 - Throws		    : DonorException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the DonorBean object
	 ********************************************************************************************************/
	public void validatePatient(PatientBean bean) throws PatientException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating donor name
		if(!(isValidName(bean.getPname()))) {
			validationErrors.add("\n Patient Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating address
		if(!(isValidAddress(bean.getPdesc()))){
			validationErrors.add("\n Description Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPno()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Donation Amount
		if(!(isValidAge(bean.getAge()))){
			validationErrors.add("\n Age Should be a positive Number \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new PatientException(validationErrors +"");
	}

	public boolean isValidName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAge(double amount){
		return (amount>0);
	}
	public boolean validatePatientId(String donorId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(donorId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}

	
	


